package com.cg.registration.stepdefinitions;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cg.registration.beans.ConferenceRegistrationPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceRegistrationStepDefinition {

	WebDriver driver = null;
	ConferenceRegistrationPage page = null;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\NewChromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		page = PageFactory.initElements(driver, ConferenceRegistrationPage.class);

	}

	@Given("^Open Conference Registration page$")
	public void open_Conference_Registration_page() throws Throwable {
		driver.get(
				"D:\\Module3Workspace\\ConferenceRegistration_153155\\src\\main\\webapp\\ConferenceRegistartion.html");
		assertEquals(driver.getTitle(), "Conference Registartion");
	}

	@When("^first name is not entered and click on submit$")
	public void first_name_is_not_entered_and_click_on_submit() throws Throwable {
		page.setFirstName("");
		page.clickNext();
	}

	@Then("^alert box display's a message$")
	public void alert_box_display_s_a_message() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the First Name");
		Thread.sleep(500);
	}

	@When("^last name is not entered and click on submit$")
	public void last_name_is_not_entered_and_click_on_submit() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("");
		page.clickNext();
	}

	@Then("^alert box display's a last name message$")
	public void alert_box_display_s_a_last_name_message() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Last Name");
		Thread.sleep(500);
	}

	@When("^empty email is entered and click on submit$")
	public void empty_email_is_entered_and_click_on_submit() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("");
		page.clickNext();
	}

	@Then("^alert box display's a email message1$")
	public void alert_box_display_s_a_email_message1() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
		Thread.sleep(500);
	}

	@When("^wrong email is entered and click on submit$")
	public void wrong_email_is_entered_and_click_on_submit() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@123");
		page.clickNext();
	}

	@Then("^alert box display's a email message$")
	public void alert_box_display_s_a_email_message() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id.");
		Thread.sleep(500);
	}

	@When("^empty contact is entered and click on submit$")
	public void empty_contact_is_entered_and_click_on_submit() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("");
		page.clickNext();
	}

	@Then("^alert box display's a empty contact message$")
	public void alert_box_display_s_a_empty_contact_message() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Contact No.");
		Thread.sleep(500);
	}

	@When("^wrong contact is entered and click on submit$")
	public void wrong_contact_is_entered_and_click_on_submit() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("999");
		page.clickNext();
	}

	@Then("^alert box display's a wrong contact message$")
	public void alert_box_display_s_a_wrong_contact_message() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Contact no.");
		Thread.sleep(500);
	}

	@When("^not selected no of people attending$")
	public void not_selected_no_of_people_attending() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("9876543210");
		// page.setNofPeopleAttending();
		page.clickNext();
	}

	@Then("^alert box display's a message for no of people$")
	public void alert_box_display_s_a_message_for_no_of_people() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Number of people attending");
		Thread.sleep(500);
	}

	@When("^building name and room number is empty$")
	public void building_name_and_room_number_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("9876543210");
		page.setNofPeopleAttending();
		page.setRoomNo("");
		page.clickNext();
	}

	@Then("^alert box display's a message for building name$")
	public void alert_box_display_s_a_message_for_building_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Building & Room No");
		Thread.sleep(500);
	}

	@When("^area name is empty$")
	public void area_name_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("9876543210");
		page.setNofPeopleAttending();
		page.setRoomNo("Blue house,442");
		page.setAreaName("");
		page.clickNext();
	}

	@Then("^alert box display's a message for area$")
	public void alert_box_display_s_a_message_for_area() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Area name");
		Thread.sleep(500);
	}

	@When("^city is not selected$")
	public void city_is_not_selected() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("9876543210");
		page.setNofPeopleAttending();
		page.setRoomNo("Blue house,442");
		page.setAreaName("Hinjewadi");
		page.clickNext();
	}

	@Then("^alert box display's a message for city$")
	public void alert_box_display_s_a_message_for_city() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select city");
		Thread.sleep(500);
	}

	@When("^state is not selected$")
	public void state_is_not_selected() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("9876543210");
		page.setNofPeopleAttending();
		page.setRoomNo("Blue house,442");
		page.setAreaName("Hinjewadi");
		page.setCity("Pune");
		page.clickNext();
	}

	@Then("^alert box display's a message for state$")
	public void alert_box_display_s_a_message_for_state() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select state");
		Thread.sleep(500);
	}

	@When("^Member Status is not selected$")
	public void member_Status_is_not_selected() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("9876543210");
		page.setNofPeopleAttending();
		page.setRoomNo("Blue house,442");
		page.setAreaName("Hinjewadi");
		page.setCity("Pune");
		page.setState("Maharashtra");
		page.clickNext();
	}

	@Then("^alert box display's a message for member selection$")
	public void alert_box_display_s_a_message_for_member_selection() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please Select MemeberShip status");
		Thread.sleep(500);
	}

	@When("^click on next button for payment$")
	public void click_on_next_button_for_payment() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setFirstName("Purva");
		page.setLastName("Patil");
		page.setEmail("pp@gmail.com");
		page.setContact("9876543210");
		page.setNofPeopleAttending();
		page.setRoomNo("Blue house,442");
		page.setAreaName("Hinjewadi");
		page.setCity("Pune");
		page.setState("Maharashtra");
		page.setMemberStatus();
		page.clickNext();
	}

	@Then("^payment page is opened$")
	public void payment_page_is_opened() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Personal details are validated.");
		driver.switchTo().alert().accept();
		//driver.close();
		// Thread.sleep(500);
	}

	/*@Given("^Open Conference Payment page$")
	public void open_Conference_Payment_page() throws Throwable {
		
		String winHandleBefore=driver.getWindowHandle();
		for(String winHandle : driver.getWindowHandles())
		{
			driver.switchTo().window(winHandle);
		}		   
		driver.switchTo().window(winHandleBefore);
		driver.get("file:///D:/Module3Workspace/ConferenceRegistration_153155/src/main/webapp/PaymentDetails.html");	
		
	    
	}*/

	@When("^card holder name is empty$")
	public void card_holder_name_is_empty() throws Throwable {
		assertEquals(driver.getTitle(), "Payment Details");
		page.setCardHolerName("");
		page.clickPaymentButton();
	}

	@Then("^alert box display's a message for empty name$")
	public void alert_box_display_s_a_message_for_empty_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
		Thread.sleep(500);
	}

	@When("^debit card number is empty$")
	public void debit_card_number_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setCardHolerName("Purva Patil");
		page.setDebitCardNo("");
		page.clickPaymentButton();
	}

	@Then("^alert box display's a message for empty number$")
	public void alert_box_display_s_a_message_for_empty_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
		Thread.sleep(500);
	}

	@When("^card expiration month is empty$")
	public void card_expiration_month_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setCardHolerName("Purva Patil");
		page.setDebitCardNo("8888999966665555");
		page.setCvv("111");
		page.setExpiryMonth("");
		page.clickPaymentButton();
	}

	@Then("^alert box display's a message for empty expiration month$")
	public void alert_box_display_s_a_message_for_empty_expiration_month() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill expiration month");
		Thread.sleep(500);
	}

	@When("^card expiration year is empty$")
	public void card_expiration_year_is_empty() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setCardHolerName("Purva Patil");
		page.setDebitCardNo("8888999966665555");
		page.setCvv("111");
		page.setExpiryMonth("02");
		page.setExpiryYear("");
		page.clickPaymentButton();
	}

	@Then("^alert box display's a message for empty expiration year$")
	public void alert_box_display_s_a_message_for_empty_expiration_year() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the expiration year");
		Thread.sleep(500);
	}

	@When("^on click of make payment$")
	public void on_click_of_make_payment() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.navigate().refresh();
		page.setCardHolerName("Purva Patil");
		page.setDebitCardNo("8888999966665555");
		page.setCvv("111");
		page.setExpiryMonth("02");
		page.setExpiryYear("2022");
		page.clickPaymentButton();
	}

	@Then("^alert box display's a message for successfull payment$")
	public void alert_box_display_s_a_message_for_successfull_payment() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Conference Room Booking successfully done!!!");
		Thread.sleep(500);
		driver.switchTo().alert().accept();
		driver.close();
	}

}
