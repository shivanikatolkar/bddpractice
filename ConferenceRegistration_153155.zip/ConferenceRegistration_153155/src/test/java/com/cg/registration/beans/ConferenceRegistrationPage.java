package com.cg.registration.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;
//POM file
public class ConferenceRegistrationPage {

	@FindBy(how=How.ID,using="txtFirstName")
	WebElement firstName;
	
	@FindBy(how=How.ID,using="txtLastName")
	WebElement lastName;
	
	@FindBy(how=How.ID,using="txtEmail")
	WebElement email;
	
	@FindBy(how=How.ID,using="txtPhone")
	WebElement contact;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[5]/td[2]/select/option[3]")
	WebElement nofPeopleAttending;
	
	@FindBy(how=How.ID,using="txtAddress1")
	WebElement roomNo;
	
	@FindBy(how=How.ID,using="txtAddress2")
	WebElement areaName;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[9]/td[2]/select")
	WebElement city;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[10]/td[2]/select")
	WebElement state;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[12]/td[2]/input")
	WebElement memberStatus;
	
	@FindBy(how=How.XPATH,using="/html/body/form/table/tbody/tr[14]/td/a")
	WebElement nextButton;
	
	@FindBy(how=How.ID,using="txtCardholderName")
	WebElement cardHolerName;
	
	@FindBy(how=How.ID,using="txtDebit")
	WebElement debitCardNo;
	
	@FindBy(how=How.ID,using="txtCvv")
	WebElement cvv;
	
	@FindBy(how=How.ID,using="txtMonth")
	WebElement expiryMonth;
	
	@FindBy(how=How.ID,using="txtYear")
	WebElement expiryYear;
	
	@FindBy(how=How.ID,using="btnPayment")
	WebElement makePaymentButton;
	
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}	
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}	
	
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}	
	public void setContact(String contact) {
		this.contact.sendKeys(contact);
	}	
	public void setNofPeopleAttending() {
		this.nofPeopleAttending.click();
	}
	
	public void setRoomNo(String roomNo) {
		this.roomNo.sendKeys(roomNo);
	}	
	public void setAreaName(String areaName) {
		this.areaName.sendKeys(areaName);
	}
	
	public void setCity(String c) {
		Select sel=new Select(city);
		sel.selectByVisibleText(c);
	}
	
	public void setState(String st) {
		Select sel=new Select(state);
		sel.selectByVisibleText(st);
	}
	
	public void setMemberStatus() {
		this.memberStatus.click();;
	}	
	public void clickNext() {
		this.nextButton.click();
	}
	
	public void setCardHolerName(String cardHolerName) {
		this.cardHolerName.sendKeys(cardHolerName);;
	}
	
	public void setDebitCardNo(String debitCardNo) {
		this.debitCardNo.sendKeys(debitCardNo);
	}
	
	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}
	
	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth.sendKeys(expiryMonth);;
	}	
	public void setExpiryYear(String expiryYear) {
		this.expiryYear.sendKeys(expiryYear);;
	}
	public void clickPaymentButton() {
		this.makePaymentButton.click();
	}
}
