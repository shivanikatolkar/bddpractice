package registration;

import static org.junit.Assert.assertEquals;


import org.openqa.selenium.WebDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.ConferenceRegPageBean;
import page.PaymentDetailsPageBean;


public class StepDef {

private WebDriver driver;
private ConferenceRegPageBean conRegPageBean;
private PaymentDetailsPageBean payDetBean;
	
@Before
public void setUp() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Downloads\\chromedriver.exe");
	driver=new org.openqa.selenium.chrome.ChromeDriver();
	//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	conRegPageBean=new ConferenceRegPageBean(driver);
	payDetBean= new PaymentDetailsPageBean(driver);
}
	
@Given("^Registration form is open$")
public void registration_form_is_open() throws Throwable {
    driver.get("E:\\BDDPractice\\Practice\\src\\main\\webapp\\ConferenceRegistartion.html");
}

@When("^I blindly click next$")
public void i_blindly_click_next() throws Throwable {
	conRegPageBean.setFirstName("");
	conRegPageBean.setBtn();
}

@Then("^I get an alert message for first name$")
public void i_get_an_alert_message_for_first_name() throws Throwable {
    assertEquals(driver.switchTo().alert().getText(), "Please fill the First Name");
    Thread.sleep(1000);
}

@When("^I enter the first name and click next$")
public void i_enter_the_first_name_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
    conRegPageBean.setFirstName("Shivani");
    conRegPageBean.setBtn();
}

@Then("^I get an alert message for last name$")
public void i_get_an_alert_message_for_last_name() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the Last Name");
    Thread.sleep(1000);
}

@When("^I enter the last name and click next$")
public void i_enter_the_last_name_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	 conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for email$")
public void i_get_an_alert_message_for_email() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
    Thread.sleep(1000);
}

@When("^I enter an invalid email and click next$")
public void i_enter_an_invalid_email_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	 conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanicom");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for valid email$")
public void i_get_an_alert_message_for_valid_email() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id.");
    Thread.sleep(1000);
}

@When("^I enter valid email and click next$")
public void i_enter_valid_email_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for phone$")
public void i_get_an_alert_message_for_phone() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the Contact No.");
    Thread.sleep(1000);
}

@When("^I enter invalid phone no and click next$")
public void i_enter_invalid_phone_no_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setContactNo("477");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for valid phone no$")
public void i_get_an_alert_message_for_valid_phone_no() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please enter valid Contact no.");
    Thread.sleep(1000);
}

@When("^I enter an valid phone and click next$")
public void i_enter_an_valid_phone_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setContactNo("7778889998");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for people attending$")
public void i_get_an_alert_message_for_people_attending() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the Number of people attending");
    Thread.sleep(1000);
}

@When("^I enter the people attending and click next$")
public void i_enter_the_people_attending_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setContactNo("7778889998");
	 conRegPageBean.setPeopleAttending("2");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for building and room no$")
public void i_get_an_alert_message_for_building_and_room_no() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the Building & Room No");
    Thread.sleep(1000);
}

@When("^I enter the building and room no and click next$")
public void i_enter_the_building_and_room_no_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setContactNo("7778889998");
	 conRegPageBean.setPeopleAttending("2");
	 conRegPageBean.setBuildingName("Vijaya");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for area name$")
public void i_get_an_alert_message_for_area_name() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the Area name");
    Thread.sleep(1000);
}

@When("^I enter the area name and click next$")
public void i_enter_the_area_name_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setContactNo("7778889998");
	 conRegPageBean.setPeopleAttending("2");
	 conRegPageBean.setBuildingName("Vijaya");
	 conRegPageBean.setAreaName("Swavalambi Nagar");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for city$")
public void i_get_an_alert_message_for_city() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please select city");
    Thread.sleep(1000);
}

@When("^I enter the city and click next$")
public void i_enter_the_city_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setContactNo("7778889998");
	 conRegPageBean.setPeopleAttending("2");
	 conRegPageBean.setBuildingName("Vijaya");
	 conRegPageBean.setAreaName("Swavalambi Nagar");
	 conRegPageBean.setCity("Pune");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for state$")
public void i_get_an_alert_message_for_state() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please select state");
    Thread.sleep(1000);
}

@When("^I enter the state and click next$")
public void i_enter_the_state_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setContactNo("7778889998");
	 conRegPageBean.setPeopleAttending("2");
	 conRegPageBean.setBuildingName("Vijaya");
	 conRegPageBean.setAreaName("Swavalambi Nagar");
	 conRegPageBean.setCity("Pune");
	 conRegPageBean.setState("Maharashtra");
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for membership status$")
public void i_get_an_alert_message_for_membership_status() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please Select MemeberShip status");
    Thread.sleep(1000);
}

@When("^I enter the membership status and click next$")
public void i_enter_the_membership_status_and_click_next() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	conRegPageBean.setFirstName("Shivani");
	 conRegPageBean.setLastName("Katolkar");
	 conRegPageBean.setEmail("shivanikatolkar@hotmail.com");
	 conRegPageBean.setContactNo("7778889998");
	 conRegPageBean.setPeopleAttending("2");
	 conRegPageBean.setBuildingName("Vijaya");
	 conRegPageBean.setAreaName("Swavalambi Nagar");
	 conRegPageBean.setCity("Pune");
	 conRegPageBean.setState("Maharashtra");
	 conRegPageBean.setMemberStatus();
	 conRegPageBean.setBtn();
}

@Then("^I get an alert message for details validated and I am navigated to payment details form$")
public void i_get_an_alert_message_for_details_validated_and_I_am_navigated_to_payment_details_form() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Personal details are validated.");
    Thread.sleep(1000);
    driver.switchTo().alert().accept();
}

@When("^I blindly click submit$")
public void i_blindly_click_submit() throws Throwable {
    payDetBean.setSubmitBtn();
}

@Then("^I get an alert message for card holder name$")
public void i_get_an_alert_message_for_card_holder_name() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
    Thread.sleep(1000);
}

@When("^I enter card holder name and click on submit$")
public void i_enter_card_holder_name_and_click_on_submit() throws Throwable {
	driver.switchTo().alert().accept();
    payDetBean.setCardHolderName("Shivani Katolkar");
    payDetBean.setSubmitBtn();
}

@Then("^I get an alert message for debit card number$")
public void i_get_an_alert_message_for_debit_card_number() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
    Thread.sleep(1000);
}

@When("^I enter debit card number and click on submit$")
public void i_enter_debit_card_number_and_click_on_submit() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	payDetBean.setCardHolderName("Shivani Katolkar");
	payDetBean.setDebitCard("1234567812345678");
    payDetBean.setSubmitBtn();
}

@Then("^I get an alert message for cvv number$")
public void i_get_an_alert_message_for_cvv_number() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the CVV");
    Thread.sleep(1000);
}

@When("^I enter cvv number and click on submit$")
public void i_enter_cvv_number_and_click_on_submit() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	payDetBean.setCardHolderName("Shivani Katolkar");
	payDetBean.setDebitCard("1234567812345678");
	payDetBean.setCvv("123");
    payDetBean.setSubmitBtn();
}

@Then("^I get an alert message for expiration month$")
public void i_get_an_alert_message_for_expiration_month() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill expiration month");
    Thread.sleep(1000);
}

@When("^I enter expiration month and click on submit$")
public void i_enter_expiration_month_and_click_on_submit() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	payDetBean.setCardHolderName("Shivani Katolkar");
	payDetBean.setDebitCard("1234567812345678");
	payDetBean.setCvv("123");
	payDetBean.setExpMonth("06");
    payDetBean.setSubmitBtn();
}

@Then("^I get an alert message for expiration year$")
public void i_get_an_alert_message_for_expiration_year() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Please fill the expiration year");
    Thread.sleep(1000);
}

@When("^I enter expiration year and click on submit$")
public void i_enter_expiration_year_and_click_on_submit() throws Throwable {
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	payDetBean.setCardHolderName("Shivani Katolkar");
	payDetBean.setDebitCard("1234567812345678");
	payDetBean.setCvv("123");
	payDetBean.setExpMonth("06");
	payDetBean.setExpYear("2022");
    payDetBean.setSubmitBtn();
}


@Then("^I get an alert message for successfull registration$")
public void i_get_an_alert_message_for_successfull_registration() throws Throwable {
	assertEquals(driver.switchTo().alert().getText(), "Conference Room Booking successfully done!!!");
    Thread.sleep(1000);
    driver.switchTo().alert().accept();
}

@After
public void tearDown() {
	driver.close();
}

}
