package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsPageBean {

	
	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement cardHolderName;
	
	@FindBy(name="debit")
	private WebElement debitCard;
	
	@FindBy(name="cvv")
	private WebElement cvv;
	
	@FindBy(name="month")
	private WebElement expMonth;
	
	@FindBy(name="year")
	private WebElement expYear;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"btnPayment\"]")
	private WebElement submitBtn;
	
	
	public PaymentDetailsPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public void setDebitCard(String debitCard) {
		this.debitCard.sendKeys(debitCard);
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public void setExpMonth(String expMonth) {
		this.expMonth.sendKeys(expMonth);
	}

	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear);
	}

	public void setSubmitBtn() {
		this.submitBtn.click();
	}

	
}


