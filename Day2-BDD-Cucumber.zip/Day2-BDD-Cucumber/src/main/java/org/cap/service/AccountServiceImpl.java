package org.cap.service;

import org.cap.exception.InvalidCustomer;
import org.cap.exception.InvalidOpeningBalance;
import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.util.AccountUtil;

public class AccountServiceImpl implements IAccountService {

	@Override
	public Account createAccount(Customer customer, double amount) throws InvalidCustomer, InvalidOpeningBalance {
		if(customer!=null) {
			if(amount>=500) {
				Account account=new Account();
				account.setCustomer(customer);
				account.setOpeningBalance(amount);
				account.setAccountNo(AccountUtil.generateAccNo());
				return account;
			}
			else {
				throw new InvalidCustomer("Sorry! Customer refers null");
		}
		
		}
		else {
			throw new InvalidOpeningBalance("Sorry! Opening balance is not sufficient");
		}

}
}
