import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Browser {

	// static WebDriver driver = new FirefoxDriver();
	static ChromeOptions chrome_options = new ChromeOptions();
	static WebDriver driver;

	//Below We are setting the properties for chrome
	
	static {
		System.setProperty("webdriver.chrome.driver",
				"E:\\ChromeDriver\\chromedriver.exe");
		chrome_options.setExperimentalOption("useAutomationExtension", false);
		chrome_options.addArguments("--no-sandbox");
		chrome_options.addArguments("--disable-dev-shm-usage");
		driver = new ChromeDriver(chrome_options);
	}

	
	
	public static void goTo(String url) {
		driver.get(url);
		//The function will return the url of the page
	}

	public static String title() {
		return driver.getTitle();
		//Function will return the title of the page
	}

	public static void close() {
		driver.close();
		//The function wil close the browser when this is called
		
	}
}
