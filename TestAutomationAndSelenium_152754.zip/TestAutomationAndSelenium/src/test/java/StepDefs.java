import org.junit.Assert;
import org.openqa.selenium.Alert;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDefs {

	private ConferencePage page = new ConferencePage();
	private Alert alert;
	private static String alertString;
	
	@Given("^I am on the conference registration page$")
	public void i_am_on_the_conference_registration_page() throws Exception {
		page.goTo();
		Assert.assertTrue(page.isAt());
	}

	@When("^I click on next$")
	public void i_click_on_next() throws Exception {
		alertString = page.clickNext();
	}

	@Then("^I get an alert message to enter first name$")
	public void i_get_an_alert_message_to_enter_first_name() throws Exception {
	    Assert.assertTrue(alertString.equals("Please fill the First Name"));
	}

	@Then("^I enter the First Name$")
	public void i_enter_the_First_Name() throws Exception {
	    page.setFirstName("Cathrine");
	}

	@Then("^I get an alert  message to enter last name$")
	public void i_get_an_alert_message_to_enter_last_name() throws Exception {
		Assert.assertTrue(alertString.equals("Please fill the Last Name"));
	}

	@Then("^I enter the last name$")
	public void i_enter_the_last_name() throws Exception {
	    page.setLastName("Brooster");
	}

	@Then("^I get an alert  message to enter email$")
	public void i_get_an_alert_message_to_enter_email() throws Exception {
	    Assert.assertTrue(alertString.equals("Please fill the Email"));
	}

	@Then("^I enter the incorrect Email address$")
	public void i_enter_the_incorrect_Email_address() throws Exception {
	    page.setIncorrectEmail("hellopage");
	}

	@Then("^I get an alert message that i enter the valid email$")
	public void i_get_an_alert_message_that_i_enter_the_valid_email() throws Exception {
		Assert.assertTrue(alertString.equals("Please enter valid Email Id."));
	}

	@Then("^I enter valid email address$")
	public void i_enter_valid_email_address() throws Exception {
	    page.setValidEmail("hello@page.com");
	}

	@Then("^I get an alert message to enter the contact number$")
	public void i_get_an_alert_message_to_enter_the_contact_number() throws Exception {
		Assert.assertTrue(alertString.equals("Please fill the Contact No."));
	}

	@Then("^I enter the invalid contact number$")
	public void i_enter_the_invalid_contact_number() throws Exception {
	    page.setInvalidContactNumber("789");
	}

	@Then("^I get an alert message to enter the valid contact number$")
	public void i_get_an_alert_message_to_enter_the_valid_contact_number() throws Exception {
		Assert.assertTrue(alertString.equals("Please enter valid Contact no."));
	}

	@Then("^I enter the valid number$")
	public void i_enter_the_valid_number() throws Exception {
	    page.setValidNumber("9638527410");
	}

	@Then("^I get an alert message that enter the number of people$")
	public void i_get_an_alert_message_that_enter_the_number_of_people() throws Exception {
		Assert.assertTrue(alertString.equals("Please fill the Number of people attending"));
	}

	@Given("^I enter the number of people$")
	public void i_enter_the_number_of_people() throws Exception {
	    page.selectNumberOfPeople();
	}

	@Then("^I get an alert message that enter the room number$")
	public void i_get_an_alert_message_that_enter_the_room_number() throws Exception {
		Assert.assertTrue(alertString.equals("Please fill the Building & Room No"));
	}

	@Given("^I enter the building name & room Number$")
	public void i_enter_the_building_name_room_Number() throws Exception {
	    page.setBuildingNameRoomNumber("Taj Room 108");
	}

	@Then("^I get an alert message that enter the area name$")
	public void i_get_an_alert_message_that_enter_the_area_name() throws Exception {
		Assert.assertTrue(alertString.equals("Please fill the Area name"));
	}

	@Given("^I enter the area name$")
	public void i_enter_the_area_name() throws Exception {
	    page.setAreaName("Marine");
	}
	
	@Then("^I get an alert message that enter the city$")
	public void i_get_an_alert_message_that_enter_the_city() throws Exception {
		Assert.assertTrue(alertString.equals("Please select city"));
	}

	@Then("^I enter the city$")
	public void i_enter_the_city() throws Exception {
	    page.setCity();
	}

	@Then("^I get an alert message that enter the state$")
	public void i_get_an_alert_message_that_enter_the_state() throws Exception {
	    Assert.assertTrue(alertString.equals("Please select state"));
	}

	@Then("^I enter the state$")
	public void i_enter_the_state() throws Exception {
	    page.selectState();
	}

	@Then("^I get an alert message that select membership$")
	public void i_get_an_alert_message_that_select_membership() throws Exception {
	    Assert.assertTrue(alertString.equals("Please Select MemeberShip status"));
	}

	@Given("^I select the membership$")
	public void i_select_the_membership() throws Exception {
	    page.selectMemberShip();
	}

	@Then("^I get an alert message that personal details are validated$")
	public void i_get_an_alert_message_that_personal_details_are_validated() throws Exception {
	    Assert.assertTrue(alertString.equals("Personal details are validated."));
	}

	@Then("^the page name is now changed to personal details$")
	public void the_page_name_is_now_changed_to_personal_details() throws Exception {
		Assert.assertTrue(page.isAt1());
	}

	@Then("^I click on make Payment$")
	public void i_click_on_make_Payment() throws Exception {
	    alertString = page.clickOnMakePayment();
	    Assert.assertTrue(alertString.equals("Please fill the Card holder name"));
	}

	@Then("^I enter the card holder name$")
	public void i_enter_the_card_holder_name() throws Exception {
	    page.setCardHolderName("Cathrine Brooster");
	}

	@When("^I click on make payment$")
	public void i_click_on_make_payment() throws Exception {
	    alertString = page.clickOnMakePayment();
	}

	@Then("^I get an alert message that enter debit card number$")
	public void i_get_an_alert_message_that_enter_debit_card_number() throws Exception {
	    Assert.assertTrue(alertString.equals("Please fill the Debit card Number"));
	}

	@Then("^I enter the number$")
	public void i_enter_the_number() throws Exception {
	    page.enterDebitCardNumber("123412341234");
	}
	
	@Then("^I get an alert message that enter CVV Number$")
	public void i_get_an_alert_message_that_enter_CVV_Number() throws Exception {
		Assert.assertTrue(alertString.equals("Please fill the CVV"));
	}

	@Then("^I enter the cvv number$")
	public void i_enter_the_cvv_number() throws Exception {
	    page.enterCvvNumber("123");
	}

	@Then("^I get an alert that please fill expiration month$")
	public void i_get_an_alert_that_please_fill_expiration_month() throws Exception {
		Assert.assertTrue(alertString.equals("Please fill expiration month"));
	}

	@Then("^I fill the month$")
	public void i_fill_the_month() throws Exception {
	    page.enterExpMonth("09");
	}

	@Then("^I get an alert that please fill expiration year$")
	public void i_get_an_alert_that_please_fill_expiration_year() throws Exception {
		Assert.assertTrue(alertString.equals("Please fill the expiration year"));
	}

	@Then("^I enter the expiration year$")
	public void i_enter_the_expiration_year() throws Exception {
	    page.enterExpYear("2022");
	}

	@Then("^I get an alert message that conference booked$")
	public void i_get_an_alert_message_that_conference_booked() throws Exception {
		Assert.assertTrue(alertString.equals("Conference Room Booking successfully done!!!"));
		Browser.close();
	}
}