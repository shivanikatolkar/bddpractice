public class PathPages {

	static String url = "file:///E:/Hitesh%20Pillai/BDD/TestAutomationAndSelenium/src/webapp/ConferenceRegistartion.html";
	static String title = "Conference Registartion";
	static String title1 = "Payment Details";
	
	public void goTo() {
		Browser.goTo(url);
		//this will make the chrome open the given url
	}

	public boolean isAt() {
		return Browser.title().equals(title);
		//Send true or flse depending upon whjether the browser titile matches the url
	}

	public boolean isAt1() {
		return Browser.title().equals(title1);
		//Send true or flse depending upon whjether the browser titile matches the url
	}
	
}
