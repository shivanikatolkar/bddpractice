import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class ConferencePage extends PathPages{

	public ConferencePage() {
		//In the cunstroctor we are initialising the annotations which we are gooing to use for finding the
//		elements
		PageFactory.initElements(Browser.driver, this);
	}
	
	private Alert alert; //Initialisze the alert variable
	
	//Below we are finding all the elements by the id name
	@FindBy(how = How.ID, id = "txtFirstName")
	private WebElement firstName;
	
	@FindBy(how = How.ID, id = "txtLastName")
	private WebElement lastName;
	
	@FindBy(how = How.ID, id = "txtEmail")
	private WebElement email;
	
	@FindBy(how = How.ID, id = "txtPhone")
	private WebElement textNumber;
	
	@FindBy(how = How.ID, id = "txtAddress1")
	private WebElement txtAddress1;

	@FindBy(how = How.ID, id = "txtAddress2")
	private WebElement Address2;
	
	@FindBy(how = How.ID, id = "txtCardholderName")
	private WebElement txtCardholderName;
	
	@FindBy(how = How.ID, id = "txtDebit")
	private WebElement txtDebit;
	
	@FindBy(how = How.ID, id = "txtCvv")
	private WebElement txtCvv;
	
	@FindBy(how = How.ID, id = "txtMonth")
	private WebElement txtMonth;
	
	@FindBy(how = How.ID, id = "txtYear")
	private WebElement txtYear;
	
	public String clickNext() {
		Browser.driver.findElement(By.tagName("a")).click();
		alert = Browser.driver.switchTo().alert();//Moving the focus to alert box
		String temp = alert.getText();//retrieving the text from the alert box
		alert.accept();//click ok on the alert
		return temp;
	}

	public void setFirstName(String string) {
		this.firstName.sendKeys(string);
	}

	public void setLastName(String string) {
		this.lastName.sendKeys(string);
	}

	public void setIncorrectEmail(String string) {
		this.email.sendKeys(string);
	}

	public void setValidEmail(String string) {
		this.email.sendKeys(string);
	}

	public void setInvalidContactNumber(String string) {
		this.textNumber.sendKeys(string);
	}

	public void setValidNumber(String string) {
		this.textNumber.clear();
		this.textNumber.sendKeys(string);
	}

	public void selectNumberOfPeople() {
		WebElement selectElement = Browser.driver.findElement(By.id("numberOfPeople"));
		Select select = new Select(selectElement);
		select.selectByVisibleText("4");
//		Above we are selecting the desired option from the drop down select tag
	}

	public void setBuildingNameRoomNumber(String string) {
		this.txtAddress1.sendKeys(string);
	}

	public void setAreaName(String string) {
		this.Address2.sendKeys(string);
	}

	public void setCity() {
		WebElement selectElement = Browser.driver.findElement(By.id("selectCity"));
		Select select = new Select(selectElement);
		select.selectByVisibleText("Hyderabad");
	}

	public void selectState() {
		WebElement selectElement = Browser.driver.findElement(By.id("selectState"));
		Select select = new Select(selectElement);
		select.selectByVisibleText("Telangana");
	}

	public void selectMemberShip() {
		Browser.driver.findElements(By.name("memberStatus")).get(1).click();
	}

	public String clickOnMakePayment() {
		Browser.driver.findElement(By.id("btnPayment")).click();
		alert = Browser.driver.switchTo().alert();
		String temp = alert.getText();
		alert.accept();
		return temp;
	}

	public void setCardHolderName(String string) {
		this.txtCardholderName.sendKeys(string);
	}

	public void enterDebitCardNumber(String string) {
		this.txtDebit.sendKeys(string);
	}

	public void enterCvvNumber(String string) {
		this.txtCvv.sendKeys(string);
	}

	public void enterExpMonth(String string) {
		this.txtMonth.sendKeys(string);
	}
	
	public void enterExpYear(String string) {
		this.txtYear.sendKeys(string);
	}
}
