package student;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.PaymentPageBean;
import page.StudentPageBean;

public class StepDef {

	private WebDriver driver;
	private StudentPageBean studentPageBean;
	private PaymentPageBean paymentPageBean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\skatolka\\Downloads\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		studentPageBean=new StudentPageBean(driver);
		paymentPageBean= new PaymentPageBean(driver);
	}
	
	@Given("^open student registration form$")
	public void open_student_registration_form() throws Throwable {
		driver.get("http://localhost:8081/Day5-StudentRegForm/");
		
	}

	@When("^all the fields are filled$")
	public void all_the_fields_are_filled() throws Throwable {
		studentPageBean.loginToNextPage("Shivani", "Katolkar", "Swavalambi Nagar", "Nagpur", "Maharashtra",
				"female", "BE", "7878787878");
	}

	@Then("^Navigate to payment page$")
	public void navigate_to_payment_page() throws Throwable {
		
		driver.switchTo().alert().accept();
		 paymentPageBean.paymentSuccessfull("SHIVANI KATOLKAR", "1234567812345678", "133", "03/20");
		 driver.switchTo().alert().accept();
		 driver.close();
	}
	
	/*@Given("^open payment details form$")
	public void open_payment_details_form() throws Throwable {
		driver.get("http://localhost:8081/Day5-StudentRegForm/payform");
	}

	@When("^all the payment fields are filled$")
	public void all_the_payment_fields_are_filled() throws Throwable {
	   paymentPageBean.paymentSuccessfull("SHIVANI KATOLKAR", "1234567812345678", "133", "03/20");
	}

	@Then("^display payment successfull$")
	public void display_payment_successfull() throws Throwable {
		driver.switchTo().alert().accept();
	}*/
/*	
	@After
	public void tearDown() {
		
	}*/

}
