package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentPageBean {

	
WebDriver driver;
	
	@FindBy(name="cardHolderName")    
	private WebElement cardHolderName;
	
	@FindBy(name="cardno")
	private WebElement cardno;
	
	@FindBy(name="CVVNumber")
	private WebElement CVVNumber;
	
	@FindBy(name="expiryDate")
	private WebElement expiryDate;
	
	@FindBy(id="Submit")
	private WebElement submitForm;
	
	public PaymentPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setCardHolderName(String cName) {
		
		cardHolderName.sendKeys(cName);
	}
	public void setCardNo(String cNo) {
		
		cardno.sendKeys(cNo);
	}
	public void setCVVNo(String cvvNo) {
	
		CVVNumber.sendKeys(cvvNo);
	}
	public void setExpiryDate(String expDate) {
	
		expiryDate.sendKeys(expDate);
	}
	public void setSubmit() {
	
		submitForm.submit();
	}
	
	public void paymentSuccessfull(String cName, String cNo, String cvvNo, String expDate) {
		this.setCardHolderName(cName);
		this.setCardNo(cNo);
		this.setCVVNo(cvvNo);
		this.setExpiryDate(expDate);
		this.setSubmit();
	}
}
