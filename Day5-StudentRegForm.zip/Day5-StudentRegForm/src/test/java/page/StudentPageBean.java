package page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class StudentPageBean {

	WebDriver driver;
	
	@FindBy(name="firstName")    
	private WebElement firstName;
	
	@FindBy(name="lastName")
	private WebElement lastName;
	
	@FindBy(name="address")
	private WebElement address;
	
	@FindBy(name="city")
	private WebElement city;
	
	@FindBy(name="state")
	private WebElement state;
	
	@FindBy(name="gender")
	private WebElement gender;
	
	@FindBy(name="course")
	private WebElement course;
	
	@FindBy(name="mobile")
	private WebElement mobile;
	
	@FindBy(id="Submit")
	private WebElement submitForm;
	
	
	public StudentPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setFirstName(String fName) {
	
		firstName.sendKeys(fName);
	}
	
	public void setLastName(String lName) {
		
		lastName.sendKeys(lName);
	}
	
	public void setAddress(String addr) {
		
		address.sendKeys(addr);
	}
	
	public void setCity(String city1) {
		
		city.sendKeys(city1);
	}

	public void setState(String state1) {
	
		state.sendKeys(state1);
	}

	public void setGender(String gen) {
	
		WebElement radio2=driver.findElement(By.id(gen));
		radio2.click();
	}

	public void setCourse(String cors) {
	
		course.sendKeys(cors);
	}

	public void setMobileNo(String mobno) {
	
		mobile.sendKeys(mobno);
	}
	
	public void setSubmit() {
		
		submitForm.submit();
	}
	
	
	public void loginToNextPage(String fName, String lName, String addr, String city1, String state1
			, String gen, String cors, String mobno) {
		
		this.setFirstName(fName);
		this.setLastName(lName);
		this.setAddress(addr);
		this.setCity(city1);
		this.setState(state1);
		this.setGender(gen);
		this.setCourse(cors);
		this.setMobileNo(mobno);
		this.setSubmit();
	}
}
