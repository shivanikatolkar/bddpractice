package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {

	WebDriver driver;
	/*private By userName=By.name("customerId");
	private By userPwd=By.name("password");
	private By subLogin=By.name("Login");*/
	
	@FindBy(name="customerId",how=How.NAME)      //how is optional, it will avoid duplicate identification
	private WebElement userName;
	
	@FindBy(name="password")
	private WebElement userPwd;
	
	@FindBy(id="login")
	private WebElement subLogin;
	
	@FindBy(xpath="//*[@id=\"homep\"]/h2")
	private WebElement pageHeading;
	
	/*private By pageHeading=By.xpath("//*[@id=\"homep\"]/h2");*/
	
	
	public LoginPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setUserName(String usrName) {
		//driver.findElement(userName).sendKeys(usrName);
		userName.sendKeys(usrName);
	}
	
	public void setUserPwd(String usrPwd) {
		//driver.findElement(userPwd).sendKeys(usrPwd);
		userPwd.sendKeys(usrPwd);
	}
	
	public void setSubmitLogin() {
		//driver.findElement(subLogin).submit();
		subLogin.submit();
	}
	
	public String getPageTitle() {
		//return driver.findElement(pageHeading).getText();
		return pageHeading.getText();
	}
	
	public void loginToNextPage(String userName, String pwd) {
		this.setUserName(userName);
		this.setUserPwd(pwd);
		this.setSubmitLogin();
	}
}
