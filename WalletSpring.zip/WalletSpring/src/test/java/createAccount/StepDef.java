package createAccount;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	@Given("^Customer details and opening balance$")
	public void customer_details_and_opening_balance() throws Throwable {
	 
	}

	@When("^For a valid customer with minimum opening balance (\\d+)$")
	public void for_a_valid_customer_with_minimum_opening_balance(int arg1) throws Throwable {
	    
	}

	@Then("^create new savings account$")
	public void create_new_savings_account() throws Throwable {
	  
	}

	@Then("^create new current account$")
	public void create_new_current_account() throws Throwable {
	   
	}

	@Then("^create new RD account$")
	public void create_new_RD_account() throws Throwable {
	   
	}

	@Then("^create new FD account$")
	public void create_new_FD_account() throws Throwable {
	
	}
}
