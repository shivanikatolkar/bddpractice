package com.wallet.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.wallet.model.Customer;

@Repository("loginDao")
@Transactional
public class LoginDaoImpl implements ILoginDao {
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public boolean validateLogin(int customerId, String password) {
		Query query=em.createQuery("from Customer where customerId=? and customerPwd=?");
		query.setParameter(0, customerId);
		query.setParameter(1, password);
		List<Customer>customers=query.getResultList();
		if(!customers.isEmpty()) {
			return true;
		}
		return false;
	}

	@Override
	public String getCustomerName(int customerId) {
		Query query
		= em.createQuery("select cust.firstName from Customer cust where cust.customerId=:custId");
	query.setParameter("custId", customerId);
	List<String> customers= query.getResultList();
	
		return customers.get(0);
	}

	@Override
	public Customer findCustomer(int customerId) {
Customer customer= em.find(Customer.class, customerId);
		
		
		return customer;
	}

	

}
