package beanPage;

/**
 * Class Name: HotelBookingPageBean
 * 
 * Author: Shivani Katolkar
 * 
 *Date: 11th August 2018
 */
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class HotelBookingPageBean {

WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;
	
	@FindBy(name="Email")
	private WebElement email;
	
	@FindBy(name="Phone")
	private WebElement mobileNo;
	
	@FindBy(how=How.XPATH,using="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	private WebElement address;
	
	@FindBy(how=How.XPATH,using="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	private WebElement city;
	
	@FindBy(how=How.XPATH,using="/html/body/div/div/form/table/tbody/tr[8]/td[2]/select")
	private WebElement state;
	
	@FindBy(how=How.XPATH,using="/html/body/div/div/form/table/tbody/tr[10]/td[2]/select")
	private WebElement noOfGuest;
	
	@FindBy(name="txtFN1")
	private WebElement cardHolderName;
	
	@FindBy(name="debit")
	private WebElement debitCard;
	
	@FindBy(name="cvv")
	private WebElement cvv;
	
	@FindBy(name="month")
	private WebElement expMonth;
	
	@FindBy(name="year")
	private WebElement expYear;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"btnPayment\"]")
	private WebElement confirmBtn;
	
	public HotelBookingPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public void setCity(String c) {
		Select sel=new Select(city);
		sel.selectByVisibleText(c);
	}

	public void setState(String st) {
		Select sel=new Select(state);
		sel.selectByVisibleText(st);
	}

	public void setNoOfGuest(String guest) {
		Select sel=new Select(noOfGuest);
		sel.selectByVisibleText(guest);
	}
	

	public void setCardHolderName(String cardHolder) {
		this.cardHolderName.sendKeys(cardHolder);
	}

	public void setDebitCard(String debitCard) {
		this.debitCard.sendKeys(debitCard);
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public void setExpMonth(String expMon) {
		this.expMonth.sendKeys(expMon); 
	}

	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear); 
	}

	public void setConfirmBtn() {
		this.confirmBtn.click();
	}

}
