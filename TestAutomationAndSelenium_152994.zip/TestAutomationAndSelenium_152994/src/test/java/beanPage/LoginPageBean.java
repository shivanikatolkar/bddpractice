package beanPage;

/**
 * Class Name: LoginPageBean
 * 
 * Author: Shivani Katolkar
 * 
 *Date: 11th August 2018
 */

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPageBean {

	
WebDriver driver;
	
	@FindBy(name="userName")
	private WebElement uName;
	
	@FindBy(name="userPwd")
	private WebElement uPwd;
	
	@FindBy(how=How.XPATH,using="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	private WebElement loginBtn;
	
	public LoginPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public void setuName(String uName) {
		this.uName.sendKeys(uName);
	}

	public void setuPwd(String uPwd) {
		this.uPwd.sendKeys(uPwd);
	}

	public void setLoginBtn() {
		this.loginBtn.click();
	}
	
	
}
