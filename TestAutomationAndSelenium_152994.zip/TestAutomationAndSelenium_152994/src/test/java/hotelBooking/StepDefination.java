package hotelBooking;

/**
 * Class Name: StepDefinations
 * 
 * Author: Shivani Katolkar
 * 
 *Date: 11th August 2018
 */

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import beanPage.HotelBookingPageBean;
import beanPage.LoginPageBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDefination {

	private WebDriver driver;
	private LoginPageBean loginPageBean;
	private HotelBookingPageBean hotelPageBean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\skatolka\\Downloads\\chromedriver.exe");
		driver=new org.openqa.selenium.chrome.ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		loginPageBean=new LoginPageBean(driver);
		hotelPageBean= new HotelBookingPageBean(driver);
	}
	
	@Given("^I am on the login page$")
	public void i_am_on_the_login_page() throws Throwable {
	    driver.get("D:\\BDD\\TestAutomationAndSelenium_152994\\src\\main\\webapp\\login.html");   
	}

	@When("^I blindly click on login$")
	public void i_blindly_click_on_login() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1"));
		loginPageBean.setuName("");
		loginPageBean.setuPwd("");
	    loginPageBean.setLoginBtn();
	    Thread.sleep(1000);
	}

/*	@Then("^I get the message for user name$")
	public void i_get_the_message_for_user_name() throws Throwable {
	   
	}*/

	@When("^I enter user name and click login$")
	public void i_enter_user_name_and_click_login() throws Throwable {
		loginPageBean.setuName("capgemini");
		loginPageBean.setLoginBtn();
		 Thread.sleep(1000);
	}

	/*@Then("^I get the message for password$")
	public void i_get_the_message_for_password() throws Throwable {
	    
	}*/

	@When("^I enter password and click login$")
	public void i_enter_password_and_click_login() throws Throwable {
		driver.navigate().refresh();
		loginPageBean.setuName("capgemini");
		loginPageBean.setuPwd("capg1234");
		loginPageBean.setLoginBtn();
		 Thread.sleep(1000);
		
	}

	@Then("^I get the hotel booking form$")
	public void i_get_the_hotel_booking_form() throws Throwable {
		 driver.get("D:\\BDD\\TestAutomationAndSelenium_152994\\src\\main\\webapp\\hotelbooking.html");
		 driver.getTitle().contains("Hotel Booking");
	}

	@When("^I blindly click on confirm booking$")
	public void i_blindly_click_on_confirm_booking() throws Throwable {
	   hotelPageBean.setConfirmBtn();
	}

	@Then("^I get the alert for first name$")
	public void i_get_the_alert_for_first_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the First Name");
	    Thread.sleep(1000);
	}

	@When("^I enter the first name and click confirm booking$")
	public void i_enter_the_first_name_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
	   hotelPageBean.setFirstName("Shivani");
	   hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for last name$")
	public void i_get_an_alert_message_for_last_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Last Name");
	    Thread.sleep(1000);
	}

	@When("^I enter the last name and click confirm booking$")
	public void i_enter_the_last_name_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for email$")
	public void i_get_an_alert_message_for_email() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
	    Thread.sleep(1000);
	}

	@When("^I enter an invalid email and click confirm booking$")
	public void i_enter_an_invalid_email_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanicom");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for valid email$")
	public void i_get_an_alert_message_for_valid_email() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id.");
	    Thread.sleep(1000);
	}

	@When("^I enter valid email and confirm booking$")
	public void i_enter_valid_email_and_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for mobile no$")
	public void i_get_an_alert_message_for_mobile_no() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Mobile No.");
	    Thread.sleep(1000);
	}

	@When("^I enter invalid mobile no and click confirm booking$")
	public void i_enter_invalid_mobile_no_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("54215");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for valid mobile no$")
	public void i_get_an_alert_message_for_valid_mobile_no() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please enter valid Contact no.");
	    Thread.sleep(1000);
	}

	@When("^I enter a valid mobile no and address and click confirm booking$")
	public void i_enter_a_valid_mobile_no_and_address_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("7778889998");
		hotelPageBean.setAddress("26, Shivaji Nagar");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for city$")
	public void i_get_an_alert_message_for_city() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select city");
	    Thread.sleep(1000);
	}

	@When("^I enter the city and click confirm booking$")
	public void i_enter_the_city_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("7778889998");
		hotelPageBean.setAddress("26, Shivaji Nagar");
		hotelPageBean.setCity("Pune");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for state$")
	public void i_get_an_alert_message_for_state() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please select state");
	    Thread.sleep(1000);
	}

	@When("^I enter the state and click confirm booking$")
	public void i_enter_the_state_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("7778889998");
		hotelPageBean.setAddress("26, Shivaji Nagar");
		hotelPageBean.setCity("Pune");
		hotelPageBean.setState("Maharashtra");
		hotelPageBean.setNoOfGuest("8");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for card holder name$")
	public void i_get_an_alert_message_for_card_holder_name() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
	    Thread.sleep(1000);
	}

	@When("^I enter the card holder name and click confirm booking$")
	public void i_enter_the_card_holder_name_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("7778889998");
		hotelPageBean.setAddress("26, Shivaji Nagar");
		hotelPageBean.setCity("Pune");
		hotelPageBean.setState("Maharashtra");
		hotelPageBean.setNoOfGuest("8");
		hotelPageBean.setCardHolderName("Shivani Katolkar");
		hotelPageBean.setConfirmBtn();
	   
	}

	@Then("^I get an alert message for debit card number$")
	public void i_get_an_alert_message_for_debit_card_number() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
	    Thread.sleep(1000);
	}

	@When("^I enter the debit card number and click confirm booking$")
	public void i_enter_the_debit_card_number_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("7778889998");
		hotelPageBean.setAddress("26, Shivaji Nagar");
		hotelPageBean.setCity("Pune");
		hotelPageBean.setState("Maharashtra");
		hotelPageBean.setNoOfGuest("8");
		hotelPageBean.setCardHolderName("Shivani Katolkar");
		hotelPageBean.setDebitCard("1234123456785678");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for CVV$")
	public void i_get_an_alert_message_for_CVV() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the CVV");
	    Thread.sleep(1000);
	}

	@When("^I enter the cvv and click confirm booking$")
	public void i_enter_the_cvv_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("7778889998");
		hotelPageBean.setAddress("26, Shivaji Nagar");
		hotelPageBean.setCity("Pune");
		hotelPageBean.setState("Maharashtra");
		hotelPageBean.setNoOfGuest("8");
		hotelPageBean.setCardHolderName("Shivani Katolkar");
		hotelPageBean.setDebitCard("1234123456785678");
		hotelPageBean.setCvv("567");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for expiration month$")
	public void i_get_an_alert_message_for_expiration_month() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill expiration month");
	    Thread.sleep(1000);
	}

	@When("^I enter the expiration month and click confirm booking$")
	public void i_enter_the_expiration_month_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("7778889998");
		hotelPageBean.setAddress("26, Shivaji Nagar");
		hotelPageBean.setCity("Pune");
		hotelPageBean.setState("Maharashtra");
		hotelPageBean.setNoOfGuest("8");
		hotelPageBean.setCardHolderName("Shivani Katolkar");
		hotelPageBean.setDebitCard("1234123456785678");
		hotelPageBean.setCvv("567");
		hotelPageBean.setExpMonth("06");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get an alert message for expiration year$")
	public void i_get_an_alert_message_for_expiration_year() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the expiration year");
	    Thread.sleep(1000);
	}

	@When("^I enter the expiration year and click confirm booking$")
	public void i_enter_the_expiration_year_and_click_confirm_booking() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelPageBean.setFirstName("Shivani");
		hotelPageBean.setLastName("Katolkar");
		hotelPageBean.setEmail("shivanikatolkar@hotmail.com");
		hotelPageBean.setMobileNo("7778889998");
		hotelPageBean.setAddress("26, Shivaji Nagar");
		hotelPageBean.setCity("Pune");
		hotelPageBean.setState("Maharashtra");
		hotelPageBean.setNoOfGuest("8");
		hotelPageBean.setCardHolderName("Shivani Katolkar");
		hotelPageBean.setDebitCard("1234123456785678");
		hotelPageBean.setCvv("567");
		hotelPageBean.setExpMonth("06");
		hotelPageBean.setExpYear("2022");
		hotelPageBean.setConfirmBtn();
	}

	@Then("^I get booking completed page$")
	public void i_get_booking_completed_page() throws Throwable {
	    driver.get("D:\\BDD\\TestAutomationAndSelenium_152994\\src\\main\\webapp\\success.html");
	    Thread.sleep(2000);
	}
	
	@After
	public void closeDown() {
		driver.close();
	}
}
