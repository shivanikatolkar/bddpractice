package hotelBooking;

/**
 * Class Name: TestRunner
 * 
 * Author: Shivani Katolkar
 * 
 *Date: 11th August 2018
 */

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(plugin= {"pretty"})
public class TestRunner {

}
