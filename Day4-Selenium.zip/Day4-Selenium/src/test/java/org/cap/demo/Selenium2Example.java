package org.cap.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Selenium2Example {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\skatolka\\Downloads\\chromedriver.exe");

		WebDriver driver =new  ChromeDriver();
		driver.get("http://localhost:8081/WalletSpring/");
		
		WebElement element=driver.findElement(By.name("customerId"));
		element.sendKeys("1");
		WebElement element1=driver.findElement(By.name("password"));
		element1.sendKeys("shivani123");
		element.submit();
		
		System.out.println("Page Title: "+driver.getTitle());
		/*
		(new WebDriverWait(driver, 10)).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return d.getTitle().toLowerCase().startsWith("Cheese!");
			}
		});
		*/
		driver.close();
		//driver.quit();
	}

}
